ALTER TABLE  `oc_customer_group_description`  ADD  `need_credit` numeric(10,4) NOT NULL default 0;
ALTER TABLE  `oc_customer`  ADD  `consumption` numeric(10,4) NOT NULL default 0;