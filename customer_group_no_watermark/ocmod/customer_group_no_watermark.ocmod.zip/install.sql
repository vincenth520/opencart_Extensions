
ALTER TABLE  `oc_customer`  ADD  `nowatermark` tinyint NOT NULL default 0;