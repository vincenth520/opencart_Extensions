DROP PROCEDURE IF EXISTS add_col_left_keywords; 

DELIMITER $$
CREATE PROCEDURE add_col_left_keywords()
BEGIN
IF NOT EXISTS(SELECT  column_name FROM information_schema.columns WHERE table_name='oc_category_description' AND column_name='left_keywords' ) THEN 
ALTER TABLE  `oc_category_description`  ADD  `left_keywords` TEXT default NULL;
END IF;
END$$
DELIMITER ; 
CALL add_col_left_keywords();