ALTER TABLE `oc_category_description` DROP `left_keywords`;
ALTER TABLE  `oc_category_description` ADD  `left_keywords` TEXT default NULL;